JCP and all original SKUNKBOARD properties (source, binary, design, etc) are released to the PUBLIC DOMAIN on 8/12/2012 (MM/DD/YYYY). No support is available, no warranty is possible, and you can do whatever you like with it, except claim ownership. :)

For as long as it's up, the full release is available at http://harmlesslion.com/software/skunk